Maps (``datascience.maps``)
===========================

.. automodule:: datascience.maps
    :members:
    :undoc-members:
