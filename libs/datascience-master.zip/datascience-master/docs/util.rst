Utility Functions (``datascience.util``)
========================================

.. automodule:: datascience.util
    :members:
    :undoc-members:
