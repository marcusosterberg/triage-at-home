Formats (``datascience.formats``)
=================================

.. automodule:: datascience.formats
    :members:
    :undoc-members:
