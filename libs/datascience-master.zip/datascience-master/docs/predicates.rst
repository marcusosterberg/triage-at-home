Predicates (``datascience.predicates``)
=======================================

.. automodule:: datascience.predicates
    :members:
    :undoc-members:
